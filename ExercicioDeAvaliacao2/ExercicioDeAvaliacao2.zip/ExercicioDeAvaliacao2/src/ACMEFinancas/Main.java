package ACMEFinancas;

public class Main {

	public static void main(String[] args) {
		ACMEFinancas aplicacao = new ACMEFinancas();
		aplicacao.inicializa();
		aplicacao.executa();
	}

}